
A = int (input("ingrese valor  ")) 
B = int(input("ingrese valor ")) 

res = A+B 
print ("la suma de los numeros es: ",res)
res = A-B 
print ("la resta de los numeros es: ",res) 
res = A*B 
print ("la multiplicacion de los numeros es: ",res)  
res = A/B 
print ("la divicion de los numeros es: ",res) 

res= A==B
print ("el numero es igual", A) 
res=A>B
print ("el numero mayor es : ",A) 
print("el numero mayor es: ", B) 
res= A==A
print("el numero es igual ",res)
res= B==B
print(res)
res= A==B
print(res)
res= B==A
print(res)