print("ingrese el primer valor")
aux1=int(input())
a= 0
print("ingrese el segundo valor")
n=int(input())
for valor in range (4):
    valor= aux1**n 
    print(valor)
    
