N = int (input("Escriba un numero :"))
aux1 = int (input("parámetro del ciclo while :"))
print ("los numeros escritos son ", N, aux1)

N = 1
while N < aux1:
    valor= aux1**N
    
    print (N)
    print ("fin")