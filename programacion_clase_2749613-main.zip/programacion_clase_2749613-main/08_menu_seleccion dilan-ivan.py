print ("esciba el numero de laods que tiene el pligono regular")
lads=int(input())
print("escriba el valores")
a=int(input())
b=int(input())
match lads:
    case 1:
        print("error no hay pligonos de un lado")
    case 2:
        print("Error no hay pologonos de dos lados ") 
    case 3:
        area=a*b/2
        print(area)
    case 4:
        area=a*b
        print(area)
    case 5:
        area=a*b/2
        print(area)
    case default:
        print("error el programa solo puede manejar hasta 5 lados")


    
  
    

         
   
    

     
        
        
    



 
        
