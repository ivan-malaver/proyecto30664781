# primer programa que escribes en un nuevo lenguaje
print("***********************************************************************\n\n\n")
print("hola mundo , hello world dilan ")
print("\n\n\n         El texto e pamtalla sirve de interacion con el usuariode un programa \n         Es precindible, sin embargo una adecuada interfasz permite claridad en la \n         ejecucion\n\n\n")
print("***********************************************************************\n\n\n")
print ("autores:\n\n        Dilan Camilo Martinez Rico\n        Ivan Malaver Fierro") 
print("\n\n***********************************************************************\n\n\n")   
