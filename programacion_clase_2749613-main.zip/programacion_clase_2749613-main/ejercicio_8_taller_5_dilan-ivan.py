print ("esciba el numero de laods que tiene el pligono regular")
lads=int(input())
if lads==1:
    print("Error no hay poligonos de un lado")
elif lads==2:
    print("Error no hay pologonos de dos lados ") 
    

 
        
