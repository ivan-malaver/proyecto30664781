v = int(input("ingrese el valor del voltage del circuito :"))
r = int(input("ingrese el valor de la resistencia del circuito :"))
res = v/r
print ("Al conectar un resistor de R", r, "ohm" " " "a una fuente de V" " ", v, " " "voltage circulará una corriente de" " ", res, " Amperios" )
