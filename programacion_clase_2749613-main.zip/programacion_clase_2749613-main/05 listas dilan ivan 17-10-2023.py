lista=  ["lunes","martes","miercoles","jueves","viernes","sabado"]
print (lista [4])
lista=  ["lunes","martes","miercoles","jueves","viernes","sabado"]
print (lista )
lista=  ["lunes","martes","miercoles","jueves","viernes","sabado"]
print (lista [0:3])
lista=  ["lunes","martes","miercoles","jueves","viernes","sabado",1,2,3["manuel",0.2,0.25,True]]
print (lista [0:3])
