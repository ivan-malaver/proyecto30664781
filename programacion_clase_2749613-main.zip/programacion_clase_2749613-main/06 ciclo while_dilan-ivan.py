print("ingrese el primer valor")
aux1=int(input())
a= 0
print("ingrese el segundo valor")
n=int(input())
while a < 5:
    valor= aux1**n 
    print(valor)
    a= a + 1
else:
    print("fin del bucle")
