#codigo Dilan - Ivan
A = float (input ("ingrese su primer numero a comparar "))
B = float (input ("ingrese su segundo numero a comparar "))
C = float (input ("ingrese su tercer numero a comparar "))
print ("su primer numero es:", A, "segundo numero", B, "tercer numero", C)
M= float 
if A>B:
    if A>C:
        M=A
    else:
        M=C
else:
    if B>C:
        M=B
    else:
        M=C
         

if ((A==B) and (A==C)):
    print("los numeros son igual")
else:
    print("el numero mayore es:",M)
    